# Trustfund Bank

This is a simple online banking frontend built with Next.js. Login is available at `/login`.