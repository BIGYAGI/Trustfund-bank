
export default function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>Welcome to TrustFund Bank</h1>
      <p><a href="/login">Login to your account</a></p>
    </div>
  );
}
